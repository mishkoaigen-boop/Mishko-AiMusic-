---
name: fl-studio-arrangement
description: خطط توزيع موسيقي في FL Studio باستخدام الـ stock plugins فقط، بما فيه ستايل سينمائي (زي Interstellar). استخدمه لطلبات التوزيع والأوركسترا والأجواء.
---

# توزيع في FL Studio (stock فقط)

## منهج الشغل
1. **الحالة العاطفية** والـ tempo والمقام (key) الأول.
2. **خريطة الأقسام** بالبارات: Intro 8 / Build 16 / Peak 16 / Break 8 / Outro 8 (عدّل حسب الأغنية).
3. **الطبقات (layers)**: Bass/Foundation، Harmony، Rhythm، Melody، Texture/FX.
4. أضف عناصر تدريجيًا؛ كل قسم جديد يضيف أو يشيل طبقة.

## أدوات stock مفيدة
- **FLEX / Sytrus / Harmless / Harmor**: Pads وLeads وBass. Harmor للـ pads المعقدة.
- **Sampler / Fruity Granulizer**: textures.
- **Fruity Reeverb 2 / Delay 3 / Fruity Parametric EQ 2 / Maximus**: مساحة وتوازن.
- **Gross Beat / Effector**: تحولات وبناء.
- Piano roll: Strum، Arpeggiator، Riff machine، Chop لتنويع.

## ستايل سينمائي (Interstellar-like)
- أورغن/Pad طويل، أرباع نوتات متكررة بتتصاعد تدريجيًا (ostinato) في سرعة مستقرة.
- Pedal bass ثابت وتغير في الهارموني فوقه.
- Build بزيادة كثافة وتردد (filter automation + reverb tail)، وذروة تتقطع فجأة لسكون.
- Automation أهم من عدد الآلات: Volume، Filter cutoff، Reverb send.

## للأغاني الشرقية
- Quantize جزئي للإحساس، Swing خفيف، مقامات (نهاوند، حجاز، صبا) عن طريق scale highlighting أو custom scale.
- ربع التون: Pitch bend automation على نوتات الـ lead.

## المخرج
جدول: قسم | بارات | الطبقات | الأتمتة | ملاحظات المكس.
