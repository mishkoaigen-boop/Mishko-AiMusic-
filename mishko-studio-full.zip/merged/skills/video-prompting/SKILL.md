---
name: video-prompting
description: اكتب برومبتات فيديو لأدوات زي Higgsfield وSeedance بلقطات محسوبة، استمرارية شخصيات، وحوار بمطابقة شفايف. استخدمه لتحويل سيناريو أو أغنية لكليب.
---

# برومبتات الفيديو

## بنية البرومبت للقطة الواحدة
`[Shot size + camera move] + [Subject: from character bible] + [Action] + [Setting + time of day] + [Lighting + color] + [Lens/style] + [Dialogue/audio]`

مثال: `Medium close-up, slow push-in. Young Egyptian man (see bible), packing a worn suitcase, mother watching from the doorway. Dusk, warm tungsten light through window, shallow depth of field, naturalistic film look.`

## الاستمرارية
- جهّز **character bible** لكل شخصية (ملامح، شعر، لبس، ثابت في كل لقطة) والصقه حرفيًا في كل برومبت.
- استخدم صورة مرجعية/Element للشخصية لو الأداة بتدعمها.
- ثبّت: الإضاءة، الباليت اللوني، العدسة لكل مشهد.

## اللقطات
- لقطة 4-8 ثواني؛ حركة كاميرا واحدة بس في اللقطة.
- نوّع: wide، medium، close-up، over-the-shoulder.
- اربط اللقطات بـ shot list فيها: رقم، مدة، برومبت، حوار، ملاحظة مونتاج.

## الحوار ومطابقة الشفايف
- اكتب الجملة بالعامية بين علامات تنصيص في البرومبت، قصيرة (أقل من 8 ثواني نطق).
- اذكر مين بيتكلم وإحساسه (بصوت مكتوم، بابتسامة حزينة).
- لو الأداة ضعيفة في العربي، ولّد الفيديو صامت ثم طبّق Lip-sync/Dubbing بصوت مسجل.

## ممنوع
- صور ثابتة مع صوت راوي.
- شخصيات حقيقية أو شعارات/شخصيات محمية.

## المخرج
- جدول Shot list بالقالب `templates/shot-list.md` وترقيم `S01-L01`.
- برومبت كل لقطة بالقالب `templates/video-prompt.md` (بطاقة الشخصية + قائمة تقييم الناتج).
- للتجميع والتطبيع بعد التوليد: `scripts/ffmpeg_tools.sh` و`scripts/audio_tools.py`.
