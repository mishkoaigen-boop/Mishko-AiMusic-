# 🎼 Mishko AI Music & Video Studio

ستوديو إنتاج موسيقى وفيديو بالذكاء الاصطناعي، بالعامية المصرية: **Skills** تخلّي Claude يشتغل كفريق إنتاج، مع **قوالب** و**سكربتات** و**سير عمل** موحّد لكل المشاريع.

## الهيكل

```
.
├── CLAUDE.md                  تعليمات المشروع الدائمة لـ Claude
├── skills/                    مهارات جاهزة (كل مجلد فيه SKILL.md)
│   ├── egyptian-lyrics/       كلمات أغاني بالعامية (راب/تراب/نوبي/شعبي)
│   ├── suno-prompting/        برومبتات Suno: ستايل + بنية + هوك وبريدج
│   ├── fl-studio-arrangement/ توزيع بأدوات FL Studio الـ stock فقط
│   ├── egyptian-screenplay/   سيناريو وإخراج فيلم مصري
│   ├── video-prompting/       برومبتات Higgsfield/Seedance + استمرارية الشخصيات
│   └── notebooklm-research/   ملفات بحث لفيديوهات اقتصادية عربية
├── workflows/
│   ├── song-to-clip.md        من الفكرة للأغنية للكليب
│   └── film-30min.md          فيلم 30 دقيقة من الفكرة للمونتاج
├── docs/workflow.md           سير العمل العام وقائمة المراجعة
├── templates/                 music-brief, video-prompt, scene-script, shot-list, character-bible
├── scripts/
│   ├── ffmpeg_tools.sh        قص، دمج، تحويل، دمج صوت، ترجمة، تطبيع
│   └── audio_tools.py         فحص ملفات الصوت وقياس/تطبيع المستوى
├── projects/
│   ├── _template/             انسخه لكل مشروع جديد
│   └── ghareeb-hena/          فيلم "غريب هناك"
└── .gitignore
```

## البدء السريع

1. انسخ `projects/_template` إلى `projects/اسم-المشروع`.
2. املأ `brief.md`: الفكرة، الجمهور، المدة، النبرة.
3. اطلب من Claude المهمة؛ يقرأ `CLAUDE.md` ثم الـ skill المناسب.
4. اكتب السيناريو (`templates/scene-script.md`) وحوّله للقطات (`templates/shot-list.md`).
5. ولّد كل لقطة بـ `templates/video-prompt.md` والموسيقى بـ `templates/music-brief.md`.
6. اجمع الناتج بسكربتات `scripts/`.

## قواعد المستودع

- كل مشروع في مجلد مستقل داخل `projects/`.
- الملفات الثقيلة (فيديو، صوت خام، `.flp`) لا تُرفع؛ احفظ روابطها داخل `brief.md`.
- كل لقطة لها رقم ثابت (مثل `S03-L02`) يُستخدم في الأسماء والبرومبتات.
- العامية المصرية الطبيعية. هوك وبريدج قبل أي شيء. لا راوي فوق صور ثابتة في الأفلام.
